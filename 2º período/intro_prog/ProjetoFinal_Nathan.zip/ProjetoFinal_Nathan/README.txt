Esses arquivos de texto já criados foram feitos usando o código do projeto final, 
e serão utilizados na apresentação final para exemplificar melhor o funcionamento;

O código foi feito em Windows, talvez perca a formatação ao rodar em Linux (Se não me engano,
o que difere é apenas o "system("cls")" ao invés de "system("clear")" e a definição da 
função "gotoxy", mas, como no combinado, vou rodar do meu notebook (que possui windows);

Os arquivos de texto (caso rode o codigo sem eles existirem) serão criados conforme o uso do
programa, ou seja, o programa sairá automaticamente caso alguma opção que necessite algum 
arquivo .txt seja selecionada antes da criação do mesmo. Um exemplo disso é tentar fazer login
no sistema antes de cadastrar um usuario (O arquivo cadastro.txt será criado ao cadastrar um 
usuario). 