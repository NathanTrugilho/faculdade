#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>

#define RED "\x1B[0;31m"
#define RED1 "\x1B[1;31m"
#define GRN "\x1B[32m"
#define YEL "\x1B[0;33m"
#define YEL1 "\x1B[1;33m"
#define CYN "\x1B[1;36m"
#define CYN0 "\x1B[0;36m"
#define WHT "\x1B[1;37;40m"

void gotoxy(int x, int y)
{
  COORD coord;
  coord.X = x;
  coord.Y = y;
  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

typedef struct data
{
    int dia;
    int mes;
    int ano;

} data;

typedef struct dados_livro
{
    char titulo[50];
    char autor[50];
    char numeroDeRegistro[9];
    char anoDePublicacao[5];
    char ISBN[15];
    char volume[4];
    char editora[40];

} dados_livro;

typedef struct usuario
{   
    char id[9];
    char nome[71];
    char email[71];
    char senha[50];  
    char curso[50];
    char CPF[20];
    char tipo; 

} dados_usuario;

typedef struct reserva
{
    char id[9];
    char numeroDeRegistro[9];

} reserva;

typedef struct emprestimo
{
    char id[9];
    char numeroDeRegistro[9];
    data dataEmprestimo, dataDevolucao;

} struct_emprestimo;

void menu_principal()
{   
    RED;
    printf("\n"WHT" ********************************************\n");
    printf(" *                                          *\n");
    printf(" *           BIBLIOTECA DO CEFET            *\n");
    printf(" *                                          *\n");
    printf(" ********************************************\n");
    printf(" *                                          *\n");
    printf(" *   --------- Menu principal ----------    *\n");
    printf(" *                                          *\n");
    printf(" *                                          *\n");
    printf(" *      1. Entrar no Sistema                *\n");
    printf(" *                                          *\n");
    printf(" *                                          *\n");
    printf(" *      2. Cadastrar Usuario                *\n");
    printf(" *                                          *\n");
    printf(" *                                          *\n");
    printf(" *      3. Sair                             *\n");
    printf(" *                                          *\n");
    printf(" *                                          *\n");
    printf(" *   -----------------------------------    *\n");
    printf(" *                                          *\n");
    printf(" ********************************************\n");
    printf("\n "YEL1"-Opcao de escolha:"WHT" ");

}

void menu_sistema(char nome[71], char id[9], char tipo)
{   
    gotoxy(51,1);  printf("******************************************************************");
    gotoxy(51,2);  printf("*                     BIBLIOTECA DO CEFET                        *");
    gotoxy(51,3);  printf("*----------------------------------------------------------------*");
    gotoxy(51,4);  printf("* usuario:                                                       *");
    gotoxy(51,5);  printf("* id:                     permissao:                             *");
    gotoxy(51,6);  printf("*----------------------------------------------------------------*");
    gotoxy(51,7);  printf("* 1. Inserir novo livro                                          *");
    gotoxy(51,8);  printf("* 2. Procurar livro por titulo                                   *");
    gotoxy(51,9);  printf("* 3. Procurar livro por autor                                    *");
    gotoxy(51,10); printf("* 4. Apagar livro                                                *");
    gotoxy(51,11); printf("* 5. Listar livros                                               *");
    gotoxy(51,12); printf("* 6. Registrar data de emprestimo e devolucao de um livro        *");
    gotoxy(51,13); printf("* 7. Registrar reserva                                           *");
    gotoxy(51,14); printf("* 8. Renovar emprestimo                                          *");
    gotoxy(51,15); printf("* 9. Sair                                                        *");
    gotoxy(51,16); printf("*----------------------------------------------------------------*");
    gotoxy(51,17); printf("* \x1B[1;33mOpcao de escolha:\x1B[1;37;40m                                              *");
    gotoxy(51,18); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                            *");
    gotoxy(51,19); printf("******************************************************************");

    gotoxy(62,4); printf("%s", nome);
    gotoxy(57,5); printf ("%s", id);

    if(tipo == 'A')
    { 
        gotoxy(88,5); printf("Aluno");
    }

    else if(tipo == 'F')
    { 
        gotoxy(88,5); printf("Funcionario da biblioteca");
    }

    else 
    {
        gotoxy(88,5); printf("Docente");
    }

}

void menu_remove_usuario()
{
    gotoxy(53,9);  printf(CYN"2. Remover cadastro "WHT);

    gotoxy(58,16); printf("********************************************************");
    gotoxy(58,17); printf("*         Insira o id do usuario a ser removido        *");
    gotoxy(58,18); printf("*         Insira '0' para voltar                       *");
    gotoxy(58,19); printf("*------------------------------------------------------*");
    gotoxy(58,20); printf("*  Id:                                                 *");
    gotoxy(58,21); printf("*  \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
    gotoxy(58,22); printf("*------------------------------------------------------*");
    gotoxy(58,23); printf("*                                                      *");
    gotoxy(58,24); printf("*  \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
    gotoxy(58,25); printf("********************************************************");

}

void menu_login()
{
    gotoxy(8,10); printf(CYN"1. Entrar no Sistema ->"WHT);

    gotoxy(65,15); printf("**************************************************");
    gotoxy(65,16); printf("*      Menu de login / Insira '0' para sair      *");
    gotoxy(65,17); printf("*------------------------------------------------*");
    gotoxy(65,18); printf("*  Insira o Id:                                  *");
    gotoxy(65,19); printf("*                                                *");
    gotoxy(65,20); printf("*  Senha:                                        *");
    gotoxy(65,21); printf("*------------------------------------------------*");
    gotoxy(65,22); printf("*                                                *");
    gotoxy(65,23); printf("*                                                *");
    gotoxy(65,24); printf("*                                                *");
    gotoxy(65,25); printf("*  \x1B[1;33m>>>\x1B[1;37;40m                                           *");
    gotoxy(65,26); printf("**************************************************");

}

void menu_cadastro()
{   
    gotoxy(8,13); printf(CYN"2. Cadastrar Usuario ->"WHT);

    gotoxy(48,1);  printf("**********************************");
    gotoxy(48,2);  printf("*                                *");
    gotoxy(48,3);  printf("*        MENU DE CADASTRO        *");
    gotoxy(48,4);  printf("*                                *");
    gotoxy(48,5);  printf("**********************************");
    gotoxy(48,6);  printf("*                                *");
    gotoxy(48,7);  printf("*    1. Criar cadastro           *");
    gotoxy(48,8);  printf("*                                *");
    gotoxy(48,9);  printf("*    2. Remover cadastro         *");
    gotoxy(48,10); printf("*                                *");
    gotoxy(48,11); printf("*    3. Voltar                   *");
    gotoxy(48,12); printf("*                                *");
    gotoxy(48,13); printf("**********************************\n");
    gotoxy(19,23); printf("  ");
    gotoxy(20,23);
}

void menu_remove_livro()
{
    gotoxy(53,10); printf(CYN"4. Apagar livro"WHT);

    gotoxy(50,21); printf("**************************************************");
    gotoxy(50,22); printf("*            Menu de remocao de livros           *");
    gotoxy(50,23); printf("*            Insira '0' para voltar              *");
    gotoxy(50,24); printf("*------------------------------------------------*");
    gotoxy(50,25); printf("* Insira o numDeRegistro:                        *");
    gotoxy(50,26); printf("*                                                *");
    gotoxy(50,27); printf("* Titulo \x1B[1;34m>>>\x1B[1;37;40m                                     *");
    gotoxy(50,28); printf("* Autor \x1B[1;34m>>>\x1B[1;37;40m                                      *");
    gotoxy(50,29); printf("*------------------------------------------------*");
    gotoxy(50,30); printf("*                                                *");
    gotoxy(50,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                            *");
    gotoxy(50,32); printf("**************************************************");

}

void limpa_remove_livro()
{
    gotoxy(47,21); printf("                                                        ");
    gotoxy(47,22); printf("                                                        ");
    gotoxy(47,23); printf("                                                        ");
    gotoxy(47,24); printf("                                                        ");
    gotoxy(47,25); printf("                                                        ");
    gotoxy(47,26); printf("                                                        ");
    gotoxy(47,27); printf("                                                        ");
    gotoxy(47,28); printf("                                                        ");
    gotoxy(47,29); printf("                                                        ");
    gotoxy(47,30); printf("                                                        ");
    gotoxy(47,31); printf("                                                        ");
    gotoxy(47,32); printf("                                                        ");
    gotoxy(47,33); printf("                                                        ");

    gotoxy(51,10); printf("* 4. Apagar livro                                                *");

}

void limpa_login()
{   
    gotoxy(65,14); printf("                                                              ");
    gotoxy(65,15); printf("                                                              ");
    gotoxy(65,16); printf("                                                              ");
    gotoxy(65,17); printf("                                                              ");
    gotoxy(65,18); printf("                                                              ");
    gotoxy(65,19); printf("                                                              ");
    gotoxy(65,20); printf("                                                              ");
    gotoxy(65,21); printf("                                                              ");
    gotoxy(65,22); printf("                                                              ");
    gotoxy(65,23); printf("                                                              ");
    gotoxy(65,24); printf("                                                              ");
    gotoxy(65,25); printf("                                                              ");
    gotoxy(65,26); printf("                                                              ");
    gotoxy(65,27); printf("                                                              ");

}

void limpa_cadastrar()
{
    gotoxy(58,16); printf("                                                                                         ");
    gotoxy(58,17); printf("                                                                                         ");
    gotoxy(58,18); printf("                                                                                         ");
    gotoxy(58,19); printf("                                                                                         ");
    gotoxy(58,20); printf("                                                                                         ");
    gotoxy(58,21); printf("                                                                                         ");
    gotoxy(58,22); printf("                                                                                         ");
    gotoxy(58,23); printf("                                                                                         ");
    gotoxy(58,24); printf("                                                                                         ");
    gotoxy(58,25); printf("                                                                                         ");
    gotoxy(58,26); printf("                                                                                         ");
    gotoxy(58,27); printf("                                                                                         ");
    gotoxy(58,28); printf("                                                                                         ");
    gotoxy(58,29); printf("                                                                                         ");
    gotoxy(58,30); printf("                                                                                         ");
    gotoxy(58,31); printf("                                                                                         ");
    gotoxy(58,32); printf("                                                                                         ");
    gotoxy(58,33); printf("                                                                                         ");
    gotoxy(58,34); printf("                                                                                         ");
}

void limpa_remove()
{
    gotoxy(58,16); printf("                                                                  ");
    gotoxy(58,17); printf("                                                                  ");
    gotoxy(58,18); printf("                                                                  ");
    gotoxy(58,19); printf("                                                                  ");
    gotoxy(58,20); printf("                                                                  ");
    gotoxy(58,21); printf("                                                                  ");
    gotoxy(58,22); printf("                                                                  ");
    gotoxy(58,23); printf("                                                                  ");
    gotoxy(58,24); printf("                                                                  ");    
    gotoxy(58,25); printf("                                                                  ");

}

void limpa_busca()

{
    gotoxy(50,21); printf("                                                                ");
    gotoxy(50,22); printf("                                                                ");
    gotoxy(50,23); printf("                                                                ");
    gotoxy(50,24); printf("                                                                ");
    gotoxy(50,25); printf("                                                                ");
    gotoxy(50,26); printf("                                                                ");
    gotoxy(50,27); printf("                                                                ");
    gotoxy(50,28); printf("                                                                ");
    gotoxy(50,29); printf("                                                                ");
    gotoxy(50,30); printf("                                                                ");
    gotoxy(50,31); printf("                                                                ");
    gotoxy(50,32); printf("                                                                ");
    gotoxy(50,33); printf("                                                                ");
    gotoxy(50,34); printf("                                                                ");
    gotoxy(50,35); printf("                                                                ");
    gotoxy(50,36); printf("                                                                ");
    gotoxy(50,37); printf("                                                                ");
}

void limpa_busca_autor(int k)
{
    for(int i = 0; k > 19; k--)
    {
        gotoxy(50,k); printf("                                                                         ");

    }

}

void limpa_listar(int k)
{
    for(int i = 0; k > 10; k--)
    {
        gotoxy(71,k); printf("                                                                                     ");

    }

}

void limpa_inserir()
{
    gotoxy(50,21); printf("                                                             ");
    gotoxy(50,22); printf("                                                             ");
    gotoxy(50,23); printf("                                                             ");
    gotoxy(50,24); printf("                                                             ");
    gotoxy(50,25); printf("                                                             ");
    gotoxy(50,26); printf("                                                             ");
    gotoxy(50,27); printf("                                                             ");
    gotoxy(50,28); printf("                                                             ");
    gotoxy(50,29); printf("                                                             ");
    gotoxy(50,30); printf("                                                             ");
    gotoxy(50,31); printf("                                                             ");
    gotoxy(50,32); printf("                                                             ");
    gotoxy(50,33); printf("                                                             ");
    gotoxy(50,34); printf("                                                             ");
    gotoxy(50,35); printf("                                                             ");
    gotoxy(50,36); printf("                                                             ");
    gotoxy(50,37); printf("                                                             ");
    gotoxy(50,38); printf("                                                             ");
    gotoxy(50,39); printf("                                                             ");

}

void limpa_reserva()
{
    gotoxy(52,22); printf("                                                       ");
    gotoxy(52,23); printf("                                                       ");
    gotoxy(52,24); printf("                                                       ");
    gotoxy(52,25); printf("                                                       ");
    gotoxy(52,26); printf("                                                       ");
    gotoxy(52,27); printf("                                                       ");
    gotoxy(52,28); printf("                                                       ");
    gotoxy(52,29); printf("                                                       ");
    gotoxy(52,30); printf("                                                       ");
    gotoxy(52,31); printf("                                                       ");
    gotoxy(52,32); printf("                                                       ");
    gotoxy(52,33); printf("                                                       ");
    gotoxy(52,34); printf("                                                       ");
    gotoxy(52,35); printf("                                                       ");
}

void limpa_emprestimo()
{
    gotoxy(52,22); printf("                                                       ");
    gotoxy(52,23); printf("                                                       ");
    gotoxy(52,24); printf("                                                       ");
    gotoxy(52,25); printf("                                                       ");
    gotoxy(52,26); printf("                                                       ");
    gotoxy(52,27); printf("                                                       ");
    gotoxy(52,28); printf("                                                       ");
    gotoxy(52,29); printf("                                                       ");
    gotoxy(52,30); printf("                                                       ");
    gotoxy(52,31); printf("                                                       ");
    gotoxy(52,32); printf("                                                       ");
    gotoxy(52,33); printf("                                                       ");
    gotoxy(52,34); printf("                                                       ");
    gotoxy(52,35); printf("                                                       ");
    gotoxy(52,36); printf("                                                       ");
    gotoxy(52,37); printf("                                                       ");
    gotoxy(52,38); printf("                                                       ");
    gotoxy(52,39); printf("                                                       ");
    gotoxy(52,40); printf("                                                       ");

}

int verifica_login(dados_usuario user[50], char verificar_id[9], int i, int identificacao)
{  
    for(;;)
    {   
        int tem = 0;

        menu_login();

        gotoxy(81,18); scanf(" %s", verificar_id);

        if (strlen(verificar_id) == 1 && verificar_id[0] == '0'){
  
            return -1;
        }
        
        if (strlen(verificar_id) != 8){

            gotoxy(72,25); printf(RED1"Id invalido!"WHT);
            gotoxy(65,27); system("pause");
            gotoxy(64,27); printf("                                                       ");
        }

        else
        {

            for(int j = 0; j < i; j++)
            {
                if(strcmp(user[j].id, verificar_id) == 0)
                {
                    tem = 1;
                    identificacao = j;
                    break;
                }

            }    

            if(tem == 0)
            {
                gotoxy(72,25); printf(RED1"Id nao cadastrado!"WHT);
                gotoxy(65,27); system("pause");
                gotoxy(65,27); printf("                                                      ");
            }
            
            else break;

        }

    }
    
    char verifica_senha[strlen(user[identificacao].senha)];

    for(;;)
    {
        gotoxy(75,20); scanf(" %s", verifica_senha);

        
        if (strlen(verifica_senha) == 1 && verifica_senha[0] == '0'){
  
            return -1;
        }

        if (strcmp(verifica_senha, user[identificacao].senha) == 0)
        {
            break;
        }
        
        else
        {
            gotoxy(72,25); printf(RED1"Senha incorreta!"WHT);
            gotoxy(75,20); printf("                                       ");
            gotoxy(65,27); system("pause");
            gotoxy(64,27); printf("                                                 ");
            gotoxy(72,25); printf("                                       ");             
        }

    }
        char final_login[1];

        gotoxy(68,22); printf("1.Entrar no Sistema ");
        gotoxy(68,23); printf("0.sair ");
        gotoxy(68,24); printf("\x1B[1;34m>>>\x1B[1;37;40m %s", user[identificacao].nome);

    for(;;)
    {
        gotoxy(72,25); scanf(" %c", &final_login[0]);

        if(final_login[0] == '0')
        {
            limpa_login();
            return -1;
        }

        if(final_login[0] == '1')
        {
            gotoxy(72,25); printf(GRN"Login feito com sucesso! "WHT);
            gotoxy(65,27); system("pause");
            limpa_login();
            return identificacao;
        }

        else
        {
            gotoxy(72,25); printf(RED1"Opcao invalida!"WHT);
            gotoxy(65,27); system("pause");
            gotoxy(64,27); printf("                                                 ");
            gotoxy(72,25); printf("                                       ");
        }
        
    }

}

int cadastrar_usuario()
{   
    FILE *pt_file;
    dados_usuario user;
    char verificacao[2];

    gotoxy(53,7);  printf(CYN"1. Criar cadastro "WHT);

    gotoxy(58,16); printf("***********************************************************************************");
    gotoxy(58,17); printf("*       Insira os dados nos campos a seguir / '0' em 'Nome' para voltar           *");
    gotoxy(58,18); printf("*---------------------------------------------------------------------------------*");
    gotoxy(58,19); printf("*  Nome:                                                                          *");
    gotoxy(58,20); printf("*                                                                                 *");
    gotoxy(58,21); printf("*  Email:                                                                         *");
    gotoxy(58,22); printf("*                                                                                 *");
    gotoxy(58,23); printf("*  CPF:                                                                           *");
    gotoxy(58,24); printf("*                                           | Id (8 termos):                      *");
    gotoxy(58,25); printf("*  Senha:                                   |                                     *");
    gotoxy(58,26); printf("*                                           | Permissao: ' '                      *");
    gotoxy(58,27); printf("*  Curso:                                   |                                     *");
    gotoxy(58,28); printf("*---------------------------------------------------------------------------------*");
    gotoxy(58,29); printf("* Tipos de permissao:              |                                              *");
    gotoxy(58,30); printf("* 'A' - Aluno                      |                                              *");
    gotoxy(58,31); printf("* 'D' - Docente                    |                                              *");
    gotoxy(58,32); printf("* 'F' - Funcionario da Biblioteca  |                                              *");
    gotoxy(58,33); printf("***********************************************************************************\n");

    gotoxy(67,19); scanf(" %s", user.nome);

    if(strlen(user.nome) == 1 && user.nome[0] == '0')
    {
        limpa_cadastrar();
        return 2;
    }

    gotoxy(68,21); scanf(" %s", user.email);
    gotoxy(66,23); scanf(" %s", user.CPF);
    gotoxy(68,25); scanf(" %s", user.senha);
    gotoxy(68,27); scanf(" %[^\n]", user.curso);

    for(;;)
    {   
        gotoxy(119,24); scanf(" %s", user.id);

        if(strlen(user.id) == 8)
        {
            gotoxy(95,32); printf("                     ");
            break;
        }
        
        gotoxy(119,24); printf("                   ");
        gotoxy(95,32); printf(RED1"Id invalido!"WHT);
    }
      
    for(;;)
    {    
        gotoxy(116,26); scanf(" %c", &user.tipo);

        gotoxy(95,32); printf("                         ");

        if(user.tipo == 'A' || user.tipo == 'D' || user.tipo == 'F') break;

        gotoxy(95,32); printf(RED1"tipo invalido!"WHT);
        gotoxy(116,26); printf(" ");
    }

    gotoxy(95,29); printf("1. Salvar cadastro    0. Sair");
    gotoxy(95,30); printf("2. Redefinir ficha ");
    gotoxy(95,31); printf(YEL1">>>"WHT);
    
    for(;;){

        gotoxy(99,31); scanf(" %c", &verificacao[0]);

        if (verificacao[0] == '0')
        {
            limpa_cadastrar();
            return 2;
        }

        if (verificacao[0] == '1')
        {

            if((pt_file = fopen("cadastro.txt", "a")) == NULL)
            {
                gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto\n"WHT);
                exit(1);
            }

            fprintf(pt_file, "%s %s %s %c %s %s %s\n", user.id, user.nome, user.senha, user.tipo, user.email, user.CPF, user.curso);

            fclose(pt_file);

            gotoxy(95,32); printf(GRN"Cadastro feito com sucesso! "WHT);
            
            gotoxy(58,34); system("pause");

            limpa_cadastrar();

            return 0;
        }

        if (verificacao[0] == '2')
        {
            return 1;
        }

        else
        {
            gotoxy(95,32); printf(RED1"Opcao invalida!"WHT);
            gotoxy(98,31); printf("                                          ");
        }

    }

}

int remove_usuario()
{   
    FILE *pt_file;
    dados_usuario user[50];
    char verificar_id[9], confirm[2];
    int i = 0, tem = 0;

    for(;;)
    {
        menu_remove_usuario();

        gotoxy(65,20); scanf(" %s", verificar_id);

        if (strlen(verificar_id) == 1 && verificar_id[0] == '0'){

            limpa_remove();   
            return 0;
        }

        if (strlen(verificar_id) != 8){

            gotoxy(65,24); printf(RED1"Id invalido!"WHT);
            gotoxy(77,27); system("pause");
            gotoxy(76,27); printf("                                                      ");
        }

        else break;

    }

    if((pt_file = fopen("cadastro.txt","r")) == NULL)
    {
        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto\n"WHT);
        exit(1);
    }

    while(fscanf(pt_file, " %s %s %s %c %s %s %s", user[i].id, user[i].nome, user[i].senha, &user[i].tipo, user[i].email, user[i].CPF, user[i].curso) == 7)
    {
        if(strcmp(user[i].id, verificar_id) == 0)
        {
            gotoxy(65,21); printf("%s", user[i].nome);
            tem = 1;
        }

        i++;
    }
    
    if(tem == 0)
    {
        gotoxy(65,24); printf(RED1"Id nao cadastrado!"WHT);
        gotoxy(58,26); system("pause");
        gotoxy(57,26); printf("                                                      ");
        return 1;
    }

    fclose(pt_file);

    for(;;)
    {   
        
        gotoxy(61,23); printf("0. Voltar    1. Confirmar");
        gotoxy(65,24); scanf(" %s", confirm);

        if(confirm[0] == '1')
        {   
            gotoxy(65,24); printf(GRN"Usuario removido com sucesso!"WHT);
            gotoxy(58,26); system("pause");
            limpa_remove();
            gotoxy(57,26); printf("                                                      ");

            pt_file = fopen("cadastro.txt","w");

            while(i > 0)
            {
                i--;

                if(strcmp(user[i].id, verificar_id) == 0) continue;
            
                fprintf(pt_file, "%s %s %s %c %s %s %s\n", user[i].id, user[i].nome, user[i].senha, user[i].tipo, user[i].email, user[i].CPF, user[i].curso);
            
            }

            fclose(pt_file);
    
            break;
        }

        else if(confirm[0] == '0')
        {
            limpa_remove();
            return 0;
        }

        else
        {
            gotoxy(65,24); printf(RED1"Opcao invalida!"WHT);
            gotoxy(58,26); system("pause");
            gotoxy(58,24); printf("*  \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
            gotoxy(57,26); printf("                                                             ");
        }

    }

}

void inserir_livro(char tipo, dados_livro livro[50], int liv)
{
    FILE *pt_file;
    dados_livro book;
    char final[2];

    if(tipo != 'F')
    {
        gotoxy(57,18); printf(RED1" Acesso negado!"WHT);
        gotoxy(51,20); system("pause");
        gotoxy(57,18); printf("                                        ");
        gotoxy(50,20); printf("                                                          ");
        gotoxy(71,17); printf("         ");
        return;
    }    

    gotoxy(53,7);  printf(CYN"1. Inserir novo livro"WHT);

    for(;;)
    {

        gotoxy(51,21); printf("**********************************************************");
        gotoxy(51,22); printf("*      Insira os dados / '0' em 'titulo' para voltar     *");
        gotoxy(51,23); printf("*--------------------------------------------------------*");
        gotoxy(51,24); printf("* Titulo:                                                *");
        gotoxy(51,25); printf("*                                                        *");
        gotoxy(51,26); printf("* Autor:                                                 *");
        gotoxy(51,27); printf("*                                                        *");
        gotoxy(51,28); printf("* Numero de Registro (8 termos):                         *");
        gotoxy(51,29); printf("*                                                        *");
        gotoxy(51,30); printf("* Ano de Publicacao:                                     *");
        gotoxy(51,31); printf("*                    Modelo ISBN: xxxxxxxxxxxxxx         *");
        gotoxy(51,32); printf("* Volume:                 | ISBN:                        *");
        gotoxy(51,33); printf("*                                                        *");
        gotoxy(51,34); printf("* Editora:                                               *");
        gotoxy(51,35); printf("*--------------------------------------------------------*");
        gotoxy(51,36); printf("*                                                        *");                         
        gotoxy(51,37); printf("* \x1B[1;33mOpcao de escolha:\x1B[1;37;40m                                      *");
        gotoxy(51,38); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                    *");
        gotoxy(51,39); printf("**********************************************************");

        gotoxy(61,24); scanf(" %s", book.titulo);

        if(strlen(book.titulo) == 1 && book.titulo[0] == '0')
        {
            limpa_inserir();
            return;
        }

        gotoxy(60,26); scanf(" %s", book.autor);
        
        for(int i;;)
        {
            gotoxy(84,28); scanf(" %s", book.numeroDeRegistro);

            if(strlen(book.numeroDeRegistro) != 8)
            {
                gotoxy(57,38); printf(RED1"Numero de registro invalido!"WHT);
                gotoxy(51,40); system("pause");
                gotoxy(57,38); printf("                                ");
                gotoxy(51,40); printf("                                            ");
                gotoxy(51,28); printf("* Numero de Registro (8 termos):                         *");
                continue;
            }

            for(i = 0; i < liv; i++)
            {
                if(strcmp(livro[i].numeroDeRegistro, book.numeroDeRegistro) == 0)
                {

                    gotoxy(57,38); printf(RED1"Numero de registro ja cadastrado!"WHT);
                    gotoxy(51,40); system("pause");
                    gotoxy(51,38); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                    *");
                    gotoxy(51,40); printf("                                            ");
                    gotoxy(51,28); printf("* Numero de Registro (8 termos):                         *");
                    break;
                }

            }

            if(i == liv) break;
        
        }

        for(;;)
        {
            gotoxy(72,30); scanf(" %s", book.anoDePublicacao);

            if(strlen(book.anoDePublicacao) != 4)
            {
                gotoxy(57,38); printf(RED1"Formatacao ou data invalida!"WHT);
                gotoxy(51,40); system("pause");
                gotoxy(57,38); printf("                                ");
                gotoxy(51,40); printf("                                            ");
                gotoxy(51,30); printf("* Ano de Publicacao:                                     *");
            }

            else break;

        }
        

        gotoxy(61,32); scanf(" %s", book.volume);

        for(;;)
        {
            gotoxy(85,32); scanf(" %s", book.ISBN);

            if(strlen(book.ISBN) != 14)
            {
                gotoxy(57,38); printf(RED1"ISBN invalido!"WHT);
                gotoxy(51,40); system("pause");
                gotoxy(51,32); printf("* Volume:                 | ISBN:                        *");
                gotoxy(56,38); printf("                                     ");
                gotoxy(51,40); printf("                                            ");

            }

            else break;

        }

        gotoxy(62,34); scanf(" %s", book.editora);

        gotoxy(53,36); printf("1.Salvar livro    2.Redefinir ficha    0.Sair");

        for(;;)
        {
            gotoxy(71,37); scanf(" %s", final);

            if(final[0] == '1')
            {
                if((pt_file = fopen("livros.txt", "a")) == NULL)
                {
                    gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto\n"WHT);
                    exit(1);
                }
                
                fprintf(pt_file, "%s %s %s %s %s %s %s\n", book.titulo, book.autor, book.numeroDeRegistro, book.anoDePublicacao, book.ISBN, book.volume, book.editora);

                fclose(pt_file);

                gotoxy(57, 38); printf(GRN"Livro adicionado com sucesso!"WHT);
                gotoxy(51, 40); system("pause");
                gotoxy(57, 38); printf("                                     ");
                gotoxy(51, 40); printf("                                            ");

                limpa_inserir();
                return;

            }

            if(final[0] == '2') break;

            if(final[0] == '0')
            {
                limpa_inserir();
                return;
            }

            else
            {
                gotoxy(57, 38); printf(RED"Opcao invalida!"WHT);
                gotoxy(51, 40); system("pause");
                gotoxy(57, 38); printf("                                ");
                gotoxy(51, 40); printf("                                            ");
                break;

            }

        }

    }

}

int remover_livro(char tipo)
{
    if(tipo != 'F')
    {
        gotoxy(57,18); printf(RED1" Acesso negado!"WHT);
        gotoxy(51,20); system("pause");
        gotoxy(57,18); printf("                                        ");
        gotoxy(50,20); printf("                                                          ");
        gotoxy(71,17); printf("         ");
        return 0;
    }

    FILE *pt_file;
    dados_livro book[50];
    char verificar_numRegistro[9], confirm[10];
    int i = 0, tem = 0;

    for(;;)
    {
        menu_remove_livro();

        gotoxy(76,25); scanf(" %s", verificar_numRegistro);

        if (strlen(verificar_numRegistro) == 1 && verificar_numRegistro[0] == '0'){

            limpa_remove_livro();
            return 0;
        }

        if (strlen(verificar_numRegistro) != 8){

            gotoxy(56,31); printf(RED1"Numero invalido!"WHT);
            gotoxy(50,33); system("pause");
            gotoxy(50,33); printf("                                                 ");
            gotoxy(50,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                            *");
            gotoxy(50,25); printf("* Insira o numDeRegistro:                        *");
        }

        else break;

    }

    if((pt_file = fopen("livros.txt","r")) == NULL)
    {
        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto\n"WHT);
        exit(1);
    }

    while(fscanf(pt_file, " %s %s %s %s %s %s %s", book[i].titulo, book[i].autor, book[i].numeroDeRegistro, book[i].anoDePublicacao, book[i].ISBN, book[i].volume, book[i].editora) == 7)
    {   

        if(strcmp(book[i].numeroDeRegistro, verificar_numRegistro) == 0)
        {
            tem = 1;

            gotoxy(63,27); printf("%s", book[i].titulo);
            gotoxy(62,28); printf("%s", book[i].autor);

        }

        i++;
    }
    
    fclose(pt_file);

    if(tem == 0)
    {
        gotoxy(56,31); printf(RED1"Livro nao cadastrado!"WHT);
        gotoxy(50,33); system("pause");
        limpa_remove_livro();
        return 1;
    }

    for(;;)
    {
        gotoxy(52,30); printf("1. Confirmar         0. Voltar");
        gotoxy(56,31); scanf(" %s", confirm);

        if(strlen(confirm) != 1)
        {
            gotoxy(56,31); printf(RED1"Opcao invalida!"WHT);
            gotoxy(50,33); system("pause");
            gotoxy(48,33); printf("                                                      ");
            gotoxy(50,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                            *");
        }

        else if(confirm[0] == '1')
        {   
            pt_file = fopen("livros.txt", "w");

            while(i > 0)
            {
                i--;

                if(strcmp(book[i].numeroDeRegistro, verificar_numRegistro) == 0) continue;
                
                fprintf(pt_file, "%s %s %s %s %s %s %s\n", book[i].titulo, book[i].autor, book[i].numeroDeRegistro, book[i].anoDePublicacao, book[i].ISBN, book[i].volume, book[i].editora);
                
            }

            fclose(pt_file);
        
            gotoxy(56,31); printf(GRN"Livro removido com sucesso!"WHT);
            gotoxy(50,33); system("pause");
            limpa_remove_livro();
            
            break;
        }

        else if(confirm[0] == '0')
        {
            limpa_remove_livro();
            return 0;
        }

        else
        {
            gotoxy(56,31); printf(RED1"Opcao invalida!"WHT);
            gotoxy(50,33); system("pause");
            gotoxy(48,33); printf("                                                      ");
            gotoxy(50,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                            *");
        }

    }

}

int busca_titulo(dados_livro livro[50], int j)
{
    char verifica_igual[50];
    int i = 0;

    gotoxy(53,8); printf(CYN"2. Procurar livro por titulo"WHT);

    gotoxy(50,21); printf("************************************************************");
    gotoxy(50,22); printf("*     Busca de livro por titulo   / '0' para sair          *");
    gotoxy(50,23); printf("*----------------------------------------------------------*");
    gotoxy(50,24); printf("* Insira o titulo do livro:                                *");
    gotoxy(50,25); printf("*                                                          *");
    gotoxy(50,26); printf("* "YEL1"Autor >>>\x1B[1;37;40m                                                *");
    gotoxy(50,27); printf("* "YEL1"NumRegistro >>>\x1B[1;37;40m                                          *");
    gotoxy(50,28); printf("* "YEL1"AnoDePublicacao >>>\x1B[1;37;40m                                      *");
    gotoxy(50,29); printf("* "YEL1"ISBN >>>\x1B[1;37;40m                                                 *");
    gotoxy(50,30); printf("* "YEL1"Volume >>>\x1B[1;37;40m                                               *");
    gotoxy(50,31); printf("* "YEL1"Editora >>>\x1B[1;37;40m                                              *");
    gotoxy(50,32); printf("*----------------------------------------------------------*");
    gotoxy(50,33); printf("*                                                          *");
    gotoxy(50,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                      *");
    gotoxy(50,35); printf("************************************************************");

    gotoxy(78,24); scanf(" %s", verifica_igual);

    if(strlen(verifica_igual) == 1 && verifica_igual[0] == '0')
    {
        limpa_busca();
        return 0;
    }

    for(i = 0; i < j; i++)
    {
        if (strcmp(livro[i].titulo, verifica_igual) == 0)
        {
            gotoxy(62,26); printf("%s", livro[i].autor);
            gotoxy(68,27); printf("%s", livro[i].numeroDeRegistro);
            gotoxy(72,28); printf("%s", livro[i].anoDePublicacao);
            gotoxy(61,29); printf("%s", livro[i].ISBN);
            gotoxy(63,30); printf("%s", livro[i].volume);
            gotoxy(64,31); printf("%s", livro[i].editora);

            break;
        }

    }

    if(i == j)
    {
        gotoxy(56,34); printf(RED1"livro nao encontrado!"WHT);
        gotoxy(50,36); system("pause");
        gotoxy(49,36); printf("                                                             ");
        gotoxy(50,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                      *");
        return 1;
    }

    gotoxy(50,33); printf("* 0.voltar        1.buscar novo livro                      *");

    char final[5];

    for(;;)
    {

        gotoxy(56,34); scanf(" %s", final);

        if (final[0] == '0')
        {
            limpa_busca();
            return 0;
        }
        
        if(final[0] == '1') return 1;

        else
        {
            gotoxy(56,34); printf(RED1"Opcao invalida!"WHT);
            gotoxy(50,36); system("pause");
            gotoxy(49,36); printf("                                                             ");
            gotoxy(50,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                      *");

        }
        
    }

}

int busca_autor(dados_livro livro[50], int j)
{
    char verifica_igual[50];
    int k = 26;

    gotoxy(53,9); printf(CYN"3. Procurar livro por autor"WHT);

    gotoxy(50,21); printf("************************************************************");
    gotoxy(50,22); printf("*     Busca de livros por autor / '0' para sair            *");
    gotoxy(50,23); printf("*----------------------------------------------------------*");
    gotoxy(50,24); printf("* Insira o nome do autor:                                  *");
    gotoxy(50,25); printf("*----------------------------------------------------------*");    

    gotoxy(76,24); scanf(" %s", verifica_igual);

    if(strlen(verifica_igual) == 1 && verifica_igual[0] == '0')
    {
        limpa_busca();
        return 0;
    }

    for(int i = 0; i < j; i++)
    {
        if (strcmp(livro[i].autor, verifica_igual) == 0)
        {
            gotoxy(50,k); printf("* "YEL1">>>\x1B[1;37;40m                                                      *");
            gotoxy(56,k); printf("%s", livro[i].titulo);
            k++;
        }

    }

    if(k == 26)
    {   
        gotoxy(50,k);   printf("*----------------------------------------------------------*");
        gotoxy(50,k+1); printf("*                                                          *");
        gotoxy(50,k+2); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                      *");
        gotoxy(50,k+3); printf("************************************************************");
        gotoxy(56,k+2); printf(RED1"Autor nao encontrado!"WHT);
        gotoxy(50,k+4); system("pause");
        gotoxy(49,k+4); printf("                                                             ");
        gotoxy(50,k+2); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                      *");
        limpa_busca();
        return 1;
    }

    gotoxy(50,k);   printf("*----------------------------------------------------------*");
    gotoxy(50,k+1); printf("*                                                          *");
    gotoxy(50,k+2); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                      *");
    gotoxy(50,k+3); printf("************************************************************");

    gotoxy(50,k+1); printf("* 0.voltar        1.buscar novo livro                      *");

    char final[5];

    for(;;)
    {

        gotoxy(56,k+2); scanf(" %s", final);

        if (final[0] == '0')
        {
            limpa_busca_autor(k+4);
            return 0;
        }
        
        if(final[0] == '1')
        {
            limpa_busca_autor(k+4);
            return 1;
        }

        else
        {
            gotoxy(56,k+2); printf(RED1"O livro nao foi encontrado!"WHT);
            gotoxy(50,k+4); system("pause");
            gotoxy(49,k+4); printf("                                                             ");
            gotoxy(50,k+2); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                      *");
        }

    }

}

void reserva_livro(dados_livro livro[50], int liv, char tipo)
{   
    if(tipo != 'F')
    {
        gotoxy(57,18); printf(RED1" Acesso negado!"WHT);
        gotoxy(51,20); system("pause");
        gotoxy(57,18); printf("                                        ");
        gotoxy(50,20); printf("                                                          ");
        gotoxy(71,17); printf("         ");
        return;
    }

    gotoxy(53,13); printf(CYN"7. Registrar reserva"WHT);

    FILE *pt_file;
    dados_usuario user[50];
    reserva reserva_var[50], reserva_verificar;
    char lixo[71], permissao;
    int u = 0, v = 0;

    if((pt_file = fopen("cadastro.txt","r")) == NULL)
    {
        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto\n"WHT);
        exit(1);
    }

    while(fscanf(pt_file, " %s %s %s %c %s %s %s", user[u].id, user[u].nome, lixo, &user[u].tipo, lixo, lixo, lixo) == 7)
    {
        u++;
    }

    fclose(pt_file);

    if((pt_file = fopen("reserva.txt","r")) == NULL)
    {
        char ver;

        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto ou nao foi encontrado. Deseja cria-lo? (S/N) "WHT);
        
        scanf(" %c", &ver);
        
        if(ver == 'S')
        {
            pt_file = fopen("reserva.txt","a");
            fclose(pt_file);

        }
        
        else
        {
            exit(1);
        }

        gotoxy(0,24); printf("                                                                                              ");
        
    }

    while(fscanf(pt_file, " %s %s", reserva_var[v].id, reserva_var[v].numeroDeRegistro) == 2)
    {
        v++;
    }

    fclose(pt_file);

    for(;;)
    {

        gotoxy(52,22); printf("*******************************************************");
        gotoxy(52,23); printf("*          Registrar reserva / '0' para sair          *");
        gotoxy(52,24); printf("*-----------------------------------------------------*");
        gotoxy(52,25); printf("* Id usuario:                                         *");
        gotoxy(52,26); printf("* NumRegistro livro:                                  *");
        gotoxy(52,27); printf("*-----------------------------------------------------*");
        gotoxy(52,28); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
        gotoxy(52,29); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
        gotoxy(52,30); printf("*-----------------------------------------------------*");
        gotoxy(52,31); printf("*                                                     *");
        gotoxy(52,32); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
        gotoxy(52,33); printf("*******************************************************");
        
        for(int i;;)
        {   
            int errado = 0;

            gotoxy(66,25); scanf(" %s", reserva_verificar.id);

            if(strlen(reserva_verificar.id) == 1 && reserva_verificar.id[0] == '0')
            {   
                limpa_reserva();
                return;
            } 

            if(strlen(reserva_verificar.id) != 8)
            {
                gotoxy(58,32); printf(RED1"Id invalido!"WHT);
                gotoxy(52,34); system("pause");
                gotoxy(52,25); printf("* Id usuario:                                         *");
                gotoxy(51,34); printf("                                                             ");
                gotoxy(52,32); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                continue;
            }

            for(i = 0; i < u; i++)
            {
                if(strcmp(reserva_verificar.id, user[i].id) == 0)
                {
                    gotoxy(58,28); printf("%s", user[i].nome);
                    permissao = user[i].tipo;
                    break;
                }
                
                if(i == u - 1)
                {

                    gotoxy(58,32); printf(RED1"Id nao cadastrado!"WHT);
                    gotoxy(52,34); system("pause");
                    gotoxy(52,25); printf("* Id usuario:                                         *");
                    gotoxy(51,34); printf("                                                             ");
                    gotoxy(52,32); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                    errado = 1;
                    break;
                }

            }   

            if(errado) continue;

            int confirm = 1;

            for(int qtd = 0, i = 0; i < v; i++)
            {
                if(strcmp(reserva_verificar.id, reserva_var[i].id) == 0)
                {
                    qtd++;
                }

                if(permissao == 'A' && qtd >= 2)
                {
                    gotoxy(58,32); printf(RED1"Numero maximo de reservas alcancado!"WHT);
                    gotoxy(52,34); system("pause");
                    gotoxy(52,25); printf("* Id usuario:                                         *");
                    gotoxy(52,28); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
                    gotoxy(51,34); printf("                                                             ");
                    gotoxy(52,32); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                    confirm = 0;
                    break;
                }

                if(permissao == 'D' && qtd >= 3)
                {
                    gotoxy(58,32); printf(RED1"Numero maximo de reservas alcancado!"WHT);
                    gotoxy(52,34); system("pause");
                    gotoxy(52,25); printf("* Id usuario:                                         *");
                    gotoxy(52,28); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
                    gotoxy(51,34); printf("                                                             ");
                    gotoxy(52,32); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                    confirm = 0;
                    break;
                }

            }

            if(confirm) break;

        }

        for(int i;;)
        {
            gotoxy(73,26); scanf(" %s", reserva_verificar.numeroDeRegistro);

            if(strlen(reserva_verificar.numeroDeRegistro) == 1 && reserva_verificar.numeroDeRegistro[0] == '0')
            {   
                limpa_reserva();
                return;
            } 

            if(strlen(reserva_verificar.numeroDeRegistro) != 8)
            {
                gotoxy(58,32); printf(RED1"numRegistro invalido!"WHT);
                gotoxy(52,34); system("pause");
                gotoxy(52,26); printf("* NumRegistro livro:                                  *");
                gotoxy(51,34); printf("                                                             ");
                gotoxy(52,32); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                continue;
            }

            for(i = 0; i < liv; i++)
            {
                if(strcmp(reserva_verificar.numeroDeRegistro, livro[i].numeroDeRegistro) == 0)
                {
                    gotoxy(58,29); printf("%s", livro[i].titulo);
                    break;
                }
            }  

            if(i == liv)
            {
                gotoxy(58,32); printf(RED1"numRegistro nao cadastrado!"WHT);
                gotoxy(52,34); system("pause");
                gotoxy(52,26); printf("* NumRegistro livro:                                  *");
                gotoxy(51,34); printf("                                                             ");
                gotoxy(52,32); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                continue;
            }

            int confirm = 1;

            for(int i = 0; i < v; i++)
            {
                if(strcmp(reserva_verificar.numeroDeRegistro, reserva_var[i].numeroDeRegistro) == 0)
                {
                    gotoxy(58,32); printf(RED1"Livro ja reservado!"WHT);
                    gotoxy(52,34); system("pause");
                    gotoxy(52,26); printf("* NumRegistro livro:                                  *");
                    gotoxy(51,34); printf("                                                             ");
                    gotoxy(52,29); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
                    gotoxy(52,32); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");

                    confirm = 0;
                    break;    
                }                

            }

            if(confirm) break;

        }

        char final[5];
        for(;;)
        {
            gotoxy(52,31); printf("*  1.Finalizar reserva    2.Refazer ficha    0.Sair   *");
            gotoxy(58,32); scanf("%s", final);

            if(final[0] == '1')
            {
                if((pt_file = fopen("reserva.txt","a")) == NULL)
                {
                    gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto\n"WHT);
                    exit(1);
                }
 
                fprintf(pt_file, "%s %s\n", reserva_verificar.id, reserva_verificar.numeroDeRegistro);

                fclose(pt_file);

                gotoxy(58,32); printf(GRN"Reserva finalizada!"WHT);
                gotoxy(52,34); system("pause");
                gotoxy(51,34); printf("                                                             ");
                gotoxy(52,32); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");

                limpa_reserva();
                return;
            }

            else if (final[0] == '2')
            {
                break;
            }

            else if (final[0] == '0')
            {
                limpa_reserva();
                return;
            }
            
            else
            {
                gotoxy(58,32); printf(RED1"Opcao invalida!"WHT);
                gotoxy(52,34); system("pause");
                gotoxy(51,34); printf("                                                             ");
                gotoxy(52,32); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
            }
            
        }

    }

}

void registrar_emprestimo(dados_livro livro[50], char tipo, int liv)
{
    if(tipo != 'F')
    {
        gotoxy(57,18); printf(RED1" Acesso negado!"WHT);
        gotoxy(51,20); system("pause");
        gotoxy(57,18); printf("                                        ");
        gotoxy(50,20); printf("                                                          ");
        gotoxy(71,17); printf("         ");
        return;
    }

    FILE *pt_file;
    dados_usuario user[50];
    reserva reserva_var[50];
    struct_emprestimo emprestimo;
    int u = 0, v =0;
    char lixo[71];

    gotoxy(53,12); printf(CYN"6. Registrar data de emprestimo e devolucao de um livro"WHT);

    if((pt_file = fopen("cadastro.txt","r")) == NULL)
    {
        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto\n"WHT);
        exit(1);
    }

    while(fscanf(pt_file, " %s %s %s %c %s %s %s", user[u].id, user[u].nome, lixo, lixo, lixo, lixo, lixo) == 7)
    {
        u++;
    }

    fclose(pt_file);

    if((pt_file = fopen("reserva.txt","r")) == NULL)
    {
        char ver;

        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto ou nao foi encontrado. Deseja cria-lo? (S/N) "WHT);
        
        scanf(" %c", &ver);
        
        if(ver == 'S')
        {
            pt_file = fopen("reserva.txt","a");
            fclose(pt_file);

        }
        if(ver == 'N')
        {
            exit(1);
        }

        gotoxy(0,24); printf("                                                                                              ");

    }

    while(fscanf(pt_file, " %s %s", reserva_var[v].id, reserva_var[v].numeroDeRegistro) == 2)
    {
        v++;
    }

    fclose(pt_file);

    for(;;)
    {
        gotoxy(52,22); printf("*******************************************************");
        gotoxy(52,23); printf("*        Registrar emprestimo / '0' para sair         *");
        gotoxy(52,24); printf("*-----------------------------------------------------*");
        gotoxy(52,25); printf("* Id usuario:                                         *");
        gotoxy(52,26); printf("* NumRegistro livro:                                  *");
        gotoxy(52,27); printf("* Data de emprestimo:                                 *");
        gotoxy(52,28); printf("* Data de devolucao:                                  *");
        gotoxy(52,29); printf("*-----------------------------------------------------*");
        gotoxy(52,30); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
        gotoxy(52,31); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
        gotoxy(52,32); printf("*-----------------------------------------------------*");
        gotoxy(52,33); printf("*                                                     *");
        gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
        gotoxy(52,35); printf("*******************************************************");

        for(int i;;)
        {   
            int errado = 1;

            gotoxy(66,25); scanf(" %s", emprestimo.id);

            if(strlen(emprestimo.id) == 1 && emprestimo.id[0] == '0')
            {   
                limpa_emprestimo();
                return;
            } 

            if(strlen(emprestimo.id) != 8)
            {
                gotoxy(58,34); printf(RED1"Id invalido!"WHT);
                gotoxy(52,36); system("pause");
                gotoxy(52,25); printf("* Id usuario:                                         *");
                gotoxy(51,36); printf("                                                             ");
                gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                gotoxy(52,30); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
                continue;
            }

            for(i = 0; i < u; i++)
            {
                if(strcmp(emprestimo.id, user[i].id) == 0)
                {
                    gotoxy(58,30); printf("%s", user[i].nome);
                    break;
                }
                
                if(i == u - 1)
                {

                    gotoxy(58,34); printf(RED1"Id nao cadastrado!"WHT);
                    gotoxy(52,36); system("pause");
                    gotoxy(52,25); printf("* Id usuario:                                         *");
                    gotoxy(51,36); printf("                                                             ");
                    gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                    gotoxy(52,30); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
                    errado = 0;
                }

            }   

            if(errado) break;
            
        }

        for(int i;;)
        {
            gotoxy(73,26); scanf(" %s", emprestimo.numeroDeRegistro);

            if(strlen(emprestimo.numeroDeRegistro) == 1 && emprestimo.numeroDeRegistro[0] == '0')
            {   
                limpa_emprestimo();
                return;
            } 

            if(strlen(emprestimo.numeroDeRegistro) != 8)
            {
                gotoxy(58,34); printf(RED1"numRegistro invalido!"WHT);
                gotoxy(52,36); system("pause");
                gotoxy(52,26); printf("* NumRegistro livro:                                  *");
                gotoxy(51,36); printf("                                                             ");
                gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                continue;
            }

            for(i = 0; i < liv; i++)
            {
                if(strcmp(emprestimo.numeroDeRegistro, livro[i].numeroDeRegistro) == 0)
                {
                    gotoxy(58,31); printf("%s", livro[i].titulo);
                    break;
                }
            }  

            if(i == liv)
            {
                gotoxy(58,34); printf(RED1"numRegistro nao cadastrado!"WHT);
                gotoxy(52,36); system("pause");
                gotoxy(52,26); printf("* NumRegistro livro:                                  *");
                gotoxy(51,36); printf("                                                             ");
                gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                continue;
            }

            int confirm = 1;

            for(int i = 0; i < v; i++)
            {
                if(strcmp(emprestimo.numeroDeRegistro, reserva_var[i].numeroDeRegistro) == 0 && strcmp(reserva_var[i].id, emprestimo.id) != 0)
                {
                    gotoxy(58,34); printf(RED1"Livro ja reservado!"WHT);
                    gotoxy(52,36); system("pause");
                    gotoxy(52,26); printf("* NumRegistro livro:                                  *");
                    gotoxy(51,36); printf("                                                             ");
                    gotoxy(52,31); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
                    gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");

                    confirm = 0;
                    break;    
                }                

            }

            if(confirm) break;

        }

        for(;;)
        {
            gotoxy(52,27); printf("* Data de emprestimo: xx/xx/xxxx                      *");
            gotoxy(74,27); scanf(" %d", &emprestimo.dataEmprestimo.dia);
            gotoxy(77,27); scanf(" %d", &emprestimo.dataEmprestimo.mes);
            gotoxy(80,27); scanf(" %d", &emprestimo.dataEmprestimo.ano);

            if(emprestimo.dataEmprestimo.dia < 1 || emprestimo.dataEmprestimo.dia > 31 || emprestimo.dataEmprestimo.mes < 1 || emprestimo.dataEmprestimo.mes > 12 || emprestimo.dataEmprestimo.ano < 2022)
            {   
                gotoxy(58,34); printf(RED1"Data invalida!"WHT);
                gotoxy(52,36); system("pause");
                gotoxy(51,36); printf("                                                             ");
                gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
            }

            else break;
        }

        for(;;)
        {
            gotoxy(52,28); printf("* Data de devolucao: xx/xx/xxxx                       *");
            gotoxy(73,28); scanf(" %d", &emprestimo.dataDevolucao.dia);
            gotoxy(76,28); scanf(" %d", &emprestimo.dataDevolucao.mes);
            gotoxy(79,28); scanf(" %d", &emprestimo.dataDevolucao.ano);
            

            if(emprestimo.dataDevolucao.dia < 1 || emprestimo.dataDevolucao.dia > 31 || emprestimo.dataDevolucao.mes < 1 || emprestimo.dataDevolucao.mes > 12 || emprestimo.dataDevolucao.ano < 2022)
            {
                gotoxy(58,34); printf(RED1"Data invalida!"WHT);
                gotoxy(52,36); system("pause");
                gotoxy(51,36); printf("                                                             ");
                gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                continue;
            }

            if(emprestimo.dataEmprestimo.ano < emprestimo.dataDevolucao.ano)
            {
                break;
            }

            else if(emprestimo.dataEmprestimo.ano > emprestimo.dataDevolucao.ano)
            {
                gotoxy(58,34); printf(RED1"Data invalida!"WHT);
                gotoxy(52,36); system("pause");
                gotoxy(51,36); printf("                                                             ");
                gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                continue;
            }

            else
            {
                if(emprestimo.dataEmprestimo.mes < emprestimo.dataDevolucao.mes)
                {
                    break;
                }

                else if(emprestimo.dataEmprestimo.mes > emprestimo.dataDevolucao.mes)
                {
                    gotoxy(58,34); printf(RED1"Data invalida!"WHT);
                    gotoxy(52,36); system("pause");
                    gotoxy(51,36); printf("                                                             ");
                    gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                    continue;
                }                

                else
                {

                    if(emprestimo.dataEmprestimo.dia < emprestimo.dataDevolucao.dia)
                    {
                        break;
                    }

                    else if(emprestimo.dataEmprestimo.dia > emprestimo.dataDevolucao.dia)
                    {
                        gotoxy(58,34); printf(RED1"Data invalida!"WHT);
                        gotoxy(52,36); system("pause");
                        gotoxy(51,36); printf("                                                             ");
                        gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                        continue;
                    }

                    else
                    {
                        gotoxy(58,34); printf(RED1"Data invalida!"WHT);
                        gotoxy(52,36); system("pause");
                        gotoxy(51,36); printf("                                                             ");
                        gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                        continue;
                    } 

                }

            }

        }

        char final[5];
        for(;;)
        {   
            gotoxy(52,33); printf("*  1.Terminar emprestimo   2.Refazer ficha   0.Sair   *");
            gotoxy(58,34); scanf("%s", final);

            if(final[0] == '1')
            {
                if((pt_file = fopen("emprestimo.txt","a")) == NULL)
                {
                    gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto\n"WHT);
                    exit(1);
                }

                fprintf(pt_file, "%s %s %d %d %d %d %d %d 0\n", emprestimo.id, emprestimo.numeroDeRegistro, emprestimo.dataEmprestimo.dia, emprestimo.dataEmprestimo.mes, emprestimo.dataEmprestimo.ano, emprestimo.dataDevolucao.dia, emprestimo.dataDevolucao.mes, emprestimo.dataDevolucao.ano);

                fclose(pt_file);

                gotoxy(58,34); printf(GRN"Emprestimo finalizado!"WHT);
                gotoxy(52,36); system("pause");
                gotoxy(51,36); printf("                                                             ");
                gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");

                limpa_emprestimo();
                return;
            }

            else if (final[0] == '2')
            {
                break;
            }

            else if (final[0] == '0')
            {
                limpa_emprestimo();
                return;
            }
            
            else
            {
                gotoxy(58,34); printf(RED1"Opcao invalida!"WHT);
                gotoxy(52,36); system("pause");
                gotoxy(51,36); printf("                                                             ");
                gotoxy(52,34); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
            }
            
        }
    
    }

}

void renovar_emprestimo(dados_livro livro[50], int liv, char id[9], char tipo)
{   
    FILE *pt_file;
    struct_emprestimo emprestimo[50], emp_aux, aux_data;
    reserva rsv[50];
    int u = 0, v = 0, renovar_qtd, renovar_vet[50];

    gotoxy(53,14); printf(CYN"8. Renovar emprestimo"WHT);

    if((pt_file = fopen("emprestimo.txt","r")) == NULL)
    {
        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto\n"WHT);
        exit(1);
    }

    while(fscanf(pt_file, "%s %s %d %d %d %d %d %d %d", emprestimo[u].id, emprestimo[u].numeroDeRegistro, &emprestimo[u].dataEmprestimo.dia, &emprestimo[u].dataEmprestimo.mes, &emprestimo[u].dataEmprestimo.ano, &emprestimo[u].dataDevolucao.dia, &emprestimo[u].dataDevolucao.mes, &emprestimo[u].dataDevolucao.ano, &renovar_vet[u]) == 9)
    {
        u++;
    }

    fclose(pt_file);

    if((pt_file = fopen("reserva.txt","r")) == NULL)
    {
        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto\n"WHT);
        exit(1);
    }

    while(fscanf(pt_file, "%s %s", rsv[v].id, rsv[v].numeroDeRegistro) == 2)
    {
        v++;
    }

    fclose(pt_file);

    strcpy(emp_aux.id, id);

    for(int i;;)
    {
        gotoxy(52,22); printf("*******************************************************");
        gotoxy(52,23); printf("*         Renovar emprestimo / '0' para sair          *");
        gotoxy(52,24); printf("*-----------------------------------------------------*");
        gotoxy(52,25); printf("* NumRegistro livro:                                  *");
        gotoxy(52,26); printf("* \x1B[1;34m>>>\x1B[1;37;40m                                                 *");
        gotoxy(52,27); printf("*-----------------------------------------------------*");
        gotoxy(52,28); printf("* Nova data de devolucao:                             *");    
        gotoxy(52,29); printf("*-----------------------------------------------------*");
        gotoxy(52,30); printf("*                                                     *");
        gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
        gotoxy(52,32); printf("*******************************************************");  

        gotoxy(73,25); scanf(" %s", emp_aux.numeroDeRegistro);

        if(strlen(emp_aux.numeroDeRegistro) == 1 && emp_aux.numeroDeRegistro[0] == '0')
        {   
            limpa_emprestimo();
            return;
        } 

        if(strlen(emp_aux.numeroDeRegistro) != 8)
        {
            gotoxy(58,31); printf(RED1"numRegistro invalido!"WHT);
            gotoxy(52,33); system("pause");
            gotoxy(52,25); printf("* NumRegistro livro:                                  *");
            gotoxy(51,33); printf("                                                             ");
            gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
            continue;
        }

        for(i = 0; i < liv; i++)
        {
            if(strcmp(emp_aux.numeroDeRegistro, livro[i].numeroDeRegistro) == 0)
            {
                gotoxy(58,26); printf("%s", livro[i].titulo);
                break;
            }
        }  

        if(i == liv)
        {
            gotoxy(58,31); printf(RED1"Livro nao emprestado!"WHT);
            gotoxy(52,33); system("pause");
            gotoxy(52,25); printf("* NumRegistro livro:                                  *");
            gotoxy(51,33); printf("                                                             ");
            gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
            continue;
        }
        
        int confirm = 0;

        for(i = 0; i < u; i++)
        {
            if(strcmp(emp_aux.numeroDeRegistro, emprestimo[i].numeroDeRegistro) == 0)
            {
                confirm = 1;
                renovar_qtd = renovar_vet[i];
                break;
            }

        }

        if(confirm == 0)
        {
            gotoxy(58,31); printf(RED1"Livro nao emprestado!"WHT);
            gotoxy(52,33); system("pause");
            gotoxy(52,25); printf("* NumRegistro livro:                                  *");
            gotoxy(51,33); printf("                                                             ");
            gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
            continue;
        }

        confirm = 1;

        for(int i = 0; i < v; i++)
        {
            if(strcmp(emp_aux.numeroDeRegistro, emprestimo[i].numeroDeRegistro) == 0 && strcmp(emprestimo[i].id, emp_aux.id) != 0)
            {
                gotoxy(58,31); printf(RED1"Emprestimo feito por outro usuario!"WHT);
                gotoxy(52,33); system("pause");
                gotoxy(52,25); printf("* NumRegistro livro:                                  *");
                gotoxy(51,33); printf("                                                             ");
                gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");

                confirm = 0;
                break;    
            }                

        }

        if(confirm == 0) continue;

        for(int qtd = 0, i = 0; i < v; i++)
        {

            if(tipo == 'A' && renovar_qtd >= 2)
            {
                gotoxy(58,31); printf(RED1"Numero maximo de renovacoes alcancado!"WHT);
                gotoxy(52,33); system("pause");
                gotoxy(51,33); printf("                                                             ");
                confirm = 0;
                break;
            }

            if(tipo == 'D' && renovar_qtd >= 3)
            {
                gotoxy(58,31); printf(RED1"Numero maximo de reservas alcancado!"WHT);
                gotoxy(52,33); system("pause");
                gotoxy(51,33); printf("                                                             ");
                confirm = 0;
                break;
            }

        }

        if(confirm == 0) continue;
        
        for(int i = 0; i < u; i++)
        {
            if(strcmp(emp_aux.numeroDeRegistro, emprestimo[i].numeroDeRegistro) == 0 && strcmp(emprestimo[i].id, emp_aux.id) == 0)
            {

                aux_data.dataEmprestimo = emprestimo[i].dataDevolucao;
                emp_aux.dataEmprestimo = emprestimo[i].dataEmprestimo;
            }

        }

        for(;;)
        {
            gotoxy(52,28); printf("* Nova data de devolucao: xx/xx/xxxx                  *");
            gotoxy(78,28); scanf(" %d", &emp_aux.dataDevolucao.dia);
            gotoxy(81,28); scanf(" %d", &emp_aux.dataDevolucao.mes);
            gotoxy(84,28); scanf(" %d", &emp_aux.dataDevolucao.ano);



            if(emp_aux.dataDevolucao.dia < 1 || emp_aux.dataDevolucao.dia > 31 || emp_aux.dataDevolucao.mes < 1 || emp_aux.dataDevolucao.mes > 12 || emp_aux.dataDevolucao.ano < 2022)
            {
                gotoxy(58,31); printf(RED1"Data invalida!"WHT);
                gotoxy(52,33); system("pause");
                gotoxy(51,33); printf("                                                             ");
                gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                continue;
            }

            if(aux_data.dataEmprestimo.ano < emp_aux.dataDevolucao.ano)
            {
                break;
            }

            else if(aux_data.dataEmprestimo.ano > emp_aux.dataDevolucao.ano)
            {
                gotoxy(58,31); printf(RED1"Data invalida!"WHT);
                gotoxy(52,33); system("pause");
                gotoxy(51,33); printf("                                                             ");
                gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                continue;
            }

            else
            {
                if(aux_data.dataEmprestimo.mes < emp_aux.dataDevolucao.mes)
                {
                    break;
                }

                else if(aux_data.dataEmprestimo.mes > emp_aux.dataDevolucao.mes)
                {
                    gotoxy(58,31); printf(RED1"Data invalida!"WHT);
                    gotoxy(52,33); system("pause");
                    gotoxy(51,33); printf("                                                             ");
                    gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                    continue;
                }                

                else
                {

                    if(aux_data.dataEmprestimo.dia < emp_aux.dataDevolucao.dia)
                    {
                        break;
                    }

                    else if(aux_data.dataEmprestimo.dia > emp_aux.dataDevolucao.dia)
                    {
                        gotoxy(58,31); printf(RED1"Data invalida!"WHT);
                        gotoxy(52,33); system("pause");
                        gotoxy(51,33); printf("                                                             ");
                        gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                        continue;
                    }

                    else
                    {
                        gotoxy(58,31); printf(RED1"Data invalida!"WHT);
                        gotoxy(52,33); system("pause");
                        gotoxy(51,33); printf("                                                             ");
                        gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
                        continue;
                    } 

                }

            }

        }

        char final[5];
        for(;;)
        {   
            gotoxy(52,30); printf("* 1.Terminar renovacao    2.Refazer ficha    0.Sair   *");
            gotoxy(58,31); scanf("%s", final);

            if(final[0] == '1')
            {
                pt_file = fopen("emprestimo.txt", "w");

                while(u > 0)
                {
                    u--;

                    if(strcmp(emprestimo[u].numeroDeRegistro, emp_aux.numeroDeRegistro) == 0)
                    {
                        fprintf(pt_file, "%s %s %d %d %d %d %d %d %d\n", emp_aux.id, emp_aux.numeroDeRegistro, emp_aux.dataEmprestimo.dia, emp_aux.dataEmprestimo.mes, emp_aux.dataEmprestimo.ano, emp_aux.dataDevolucao.dia, emp_aux.dataDevolucao.mes, emp_aux.dataDevolucao.ano, (renovar_qtd + 1));
                    } 
        
                    else
                    {
                        fprintf(pt_file, "%s %s %d %d %d %d %d %d %d\n", emprestimo[u].id, emprestimo[u].numeroDeRegistro, emprestimo[u].dataEmprestimo.dia, emprestimo[u].dataEmprestimo.mes, emprestimo[u].dataEmprestimo.ano, emprestimo[u].dataDevolucao.dia, emprestimo[u].dataDevolucao.mes, emprestimo[u].dataDevolucao.ano, renovar_vet[u]);
                    }

                }

                fclose(pt_file);

                gotoxy(58,31); printf(GRN"Renovacao finalizada!"WHT);
                gotoxy(52,33); system("pause");
                gotoxy(51,33); printf("                                                             ");
                gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");

                limpa_emprestimo();
                return;
            }

            else if (final[0] == '2')
            {
                break;
            }

            else if (final[0] == '0')
            {
                limpa_emprestimo();
                return;
            }
            
            else
            {
                gotoxy(58,31); printf(RED1"Opcao invalida!"WHT);
                gotoxy(52,33); system("pause");
                gotoxy(51,33); printf("                                                             ");
                gotoxy(52,31); printf("* \x1B[1;33m>>>\x1B[1;37;40m                                                 *");
            }        
        }      
    
    }

}

void lista_livros(dados_livro livro[50], int liv)
{
    FILE *pt_file;
    struct_emprestimo emprestimo[50], emp_lixo;
    reserva rsv[50];
    char lixo[51], situacao;
    int u = 0, v = 0, k = 17, lixoi;
    
    if((pt_file = fopen("emprestimo.txt","r")) == NULL)
    {
        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto ou nao existe\n"WHT);
        exit(1);
    }

    while(fscanf(pt_file, "%s %s %d %d %d %d %d %d %d", lixo, emprestimo[u].numeroDeRegistro, &emp_lixo.dataDevolucao.dia, &emp_lixo.dataDevolucao.mes, &emp_lixo.dataDevolucao.ano, &emp_lixo.dataDevolucao.ano, &emp_lixo.dataDevolucao.mes, &emp_lixo.dataDevolucao.dia, &lixoi) == 9)
    {
        u++;
    }

    fclose(pt_file);

    if((pt_file = fopen("reserva.txt","r")) == NULL)
    {
        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto ou nao existe\n"WHT);
        exit(1);
    }

    while(fscanf(pt_file, "%s %s", lixo, rsv[v].numeroDeRegistro) == 2)
    {
        v++;
    }

    fclose(pt_file);

    gotoxy(53,11); printf(CYN"5. Listar livros"WHT);

    gotoxy(73,12); printf(" ********************************************************************************");
    gotoxy(73,13); printf(" *                             Acervo da biblioteca                             *");
    gotoxy(73,14); printf(" *------------------------------------------------------------------------------*");
    gotoxy(73,15); printf(" * Titulo:                            || Situacao:                              *");
    gotoxy(73,16); printf(" *                                    ||                                        *");
   
    for(int i = 0, j = 0; i < liv; i++, k++)
    {
        gotoxy(73,k); printf(" * "YEL1">>>\x1B[1;37;40m                                ||                                        *");
        gotoxy(79,k); printf(" %s", livro[i].titulo);

        for(j = 0; j < u; j++)
        {
            if(strcmp(livro[i].numeroDeRegistro, emprestimo[j].numeroDeRegistro) == 0)
            {
                gotoxy(114,k); printf(RED1" Emprestado!"WHT);
                break;
            }

        }

        if(j == u)
        {

            for(j = 0; j < v; j++)
            {
                if(strcmp(livro[i].numeroDeRegistro, rsv[j].numeroDeRegistro) == 0)
                {
                    gotoxy(114,k); printf(YEL1" Reservado!"WHT);
                    break;
                }

            }

            if(j == v)
            {   
                gotoxy(114,k); printf(GRN" Disponivel!"WHT);
            }

        }

    }

    gotoxy(73,k); printf(" *------------------------------------------------------------------------------*");
    gotoxy(73,k+1); printf(" ********************************************************************************");
    gotoxy(74,k+2); system("pause");

    limpa_listar(k+3);

}

void sistema_main(char id[9], char nome[71], char tipo)
{
    FILE *pt_file;
    dados_livro livro[50];
    char arquivo;
    int i = 0;

    for(;;)
    {   
        menu_sistema(nome, id, tipo);
           
        i = 0;

        if((pt_file = fopen("livros.txt","r")) == NULL)
        {
            gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto ou nao existe! Deseja cria-lo? (S/N)\n"WHT);
            
            scanf(" %c", &arquivo);
            
            if (arquivo == 'S')
            {
                pt_file = fopen("livros.txt","a");
                fclose(pt_file);
            } 

            else exit(1);
        }

        while(fscanf(pt_file, " %s %s %s %s %s %s %s", livro[i].titulo, livro[i].autor, livro[i].numeroDeRegistro, livro[i].anoDePublicacao, livro[i].ISBN, livro[i].volume, livro[i].editora) == 7)
        {   

            i++;
        }
        
        fclose(pt_file);

        char var_sistema[15];
        gotoxy(70,17); printf("                 ");
        gotoxy(71,17); scanf(" %s", var_sistema);

        switch (var_sistema[0])
        {
        case '1':
            inserir_livro(tipo, livro, i); 
            break;
        
        case'2':
            while(busca_titulo(livro, i));
            break;

        case '3':
            while(busca_autor(livro, i));
            break;

        case '4':
            while(remover_livro(tipo));
            break;
        
        case '5':
            lista_livros(livro, i);
            break;

        case '6':
            registrar_emprestimo(livro, tipo, i);
            break;

        case '7':
            reserva_livro(livro, i, tipo);
            break;

        case '8':
            renovar_emprestimo(livro, i, id, tipo);
            break;

        case '9':
            return;

        default:
            gotoxy(57,18); printf(RED1" -Opcao invalida!"WHT);
            gotoxy(51,20); system("pause");
            gotoxy(57,18); printf("                                        ");
            gotoxy(70,17); printf("                                        ");
            gotoxy(50,20); printf("                                                          "); 
            break;
        }

    }

}

void login()
{   
    FILE *pt_file;
    dados_usuario user[50];
    char verificar_id[9];
    int i = 0, identificacao;
    char lixo[40];

    if((pt_file = fopen("cadastro.txt","r")) == NULL)
    {
        gotoxy(0,24); printf(RED" O arquivo nao pode ser aberto ou nao existe!\n"WHT);
        exit(1);
    }
    
    while(fscanf(pt_file, " %s %s %s %c %s %s %s", user[i].id, user[i].nome, user[i].senha, &user[i].tipo, lixo, lixo, lixo) == 7)
    {
        i++;
    }

    fclose(pt_file);

    int a = verifica_login(user, verificar_id, i, identificacao);
    
    identificacao = a;

    if(a == -1) return;

    else sistema_main(user[identificacao].id, user[identificacao].nome, user[identificacao].tipo);

}

void cadastro()
{
    for(;;)
    {
        menu_cadastro();

        char cad[2];
        scanf(" %s", cad);

        switch (cad[0])
        {
        case '1':

            while (cadastrar_usuario() == 1);
            break;
        
        case '2':
            while (remove_usuario());
            break;

        case '3':
            return;

        default:
            printf(RED1" -Opcao invalida!"WHT);
            gotoxy(2,25); system("pause");
            gotoxy(20,23); printf("                                                  ");
            gotoxy(0,24); printf("                                                  ");
            gotoxy(0,25); printf("                                                  ");
        }

    }

}

void main()
{

    for(;;)
    {
        system("cls");
        menu_principal();
        
        char menu_principal[2]; 
        scanf(" %s", menu_principal);

        switch (menu_principal[0])
        {
        case '1':
            login();
            break;
        
        case '2':
            cadastro();
            break;

        case '3':
            printf(RED" -Saindo...\n"WHT);
            return;    

        default:
            printf(RED1" -Opcao invalida!"WHT);
            gotoxy(2,25); system("pause");

        }

    }

}